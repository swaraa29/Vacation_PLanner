package com.example.vacationplanner.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vacationplanner.R;
import com.example.vacationplanner.model.RecentsData;
import com.example.vacationplanner.model.TopPlacessData;

import java.util.List;

public class TopPlacesAdapter extends RecyclerView.Adapter<TopPlacesAdapter.TopPlacesViewHolder>{

    Context context;
    List<TopPlacessData> topPlacessDataList;

    public TopPlacesAdapter(List<TopPlacessData> recentsDataList, Context context) {
        this.topPlacessDataList = recentsDataList;
        this.context = context;
    }

    @NonNull
    @Override
    public TopPlacesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.top_places_row_item,parent,false);

        // Recylar view item layout file
        return new TopPlacesViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull TopPlacesViewHolder holder, int position) {
        holder.countryname.setText(topPlacessDataList.get(position).getCountryName());
        holder.placeName.setText(topPlacessDataList.get(position).getPlaceName());
        holder.price.setText(topPlacessDataList.get(position).getPrice());
        holder.placeImage.setImageResource(topPlacessDataList.get(position).getImageUrl());

    }

    @Override
    public int getItemCount() {
        return topPlacessDataList.size();
    }


    public static final class TopPlacesViewHolder extends RecyclerView.ViewHolder{
        ImageView placeImage;
        TextView placeName,countryname,price;


        public TopPlacesViewHolder(@NonNull View itemView) {
            super(itemView);

            placeImage = itemView.findViewById(R.id.place_image);
            placeName =  itemView.findViewById(R.id.place_name);
            countryname=itemView.findViewById(R.id.country_name);
            price = itemView.findViewById(R.id.price);

        }
    }


}
